# Sleep Calculator Pro (Deploy-Ready)

A modern, responsive Sleep Calculator with advanced features:
- Sleep-cycle based calculations with fall-asleep presets (7/14/21 min)
- Quality of Sleep Estimator (progress bar + ring)
- Smart Notifications (Notification API)
- Sleep Debt Tracker (Chart.js)
- Rule-based Tips
- Pre-Sleep Routine checklist
- Export to Google Calendar and .ics
- Multiple Day Planning (weekday/weekend)

## Quickstart
Open `index.html` directly in your browser — no build step needed.

Or serve locally for nicer dev:
```bash
python -m http.server 8080
# visit http://localhost:8080
```

## Deploy Options

### 1) GitHub Pages
1. Create a new repo (e.g., `sleep-calculator-pro`).
2. Add/commit these files. Push to `main`.
3. In GitHub → Settings → Pages:
   - Source: **Deploy from a branch**
   - Branch: **main** (root)
4. Your site will be live at `https://<username>.github.io/sleep-calculator-pro/`.

### 2) Vercel
1. Go to https://vercel.com/new and **Import Git Repository**.
2. Framework Preset: **Other** (it’s a static site).
3. Root Directory: `/` (project root).
4. Click **Deploy**.
> `vercel.json` is included for static settings (optional).

### 3) Netlify
1. Go to https://app.netlify.com/start → **Import from Git**.
2. Build command: **None** (static).
3. Publish directory: `/` (project root).
4. **Deploy**.
> `netlify.toml` provides sensible defaults (optional).

## Files
- `index.html` — Single-file app (Tailwind CDN + Chart.js)
- `assets/favicon.svg` — Favicon
- `netlify.toml` — Netlify config (optional)
- `vercel.json` — Vercel config (optional)
- `LICENSE` — MIT
- `README.md` — You are here

## License
MIT
